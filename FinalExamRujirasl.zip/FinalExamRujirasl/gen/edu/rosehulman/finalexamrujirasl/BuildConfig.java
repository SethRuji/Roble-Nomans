/** Automatically generated file. DO NOT MODIFY */
package edu.rosehulman.finalexamrujirasl;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}