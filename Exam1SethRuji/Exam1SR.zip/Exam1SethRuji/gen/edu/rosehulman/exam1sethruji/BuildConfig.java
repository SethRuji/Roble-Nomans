/** Automatically generated file. DO NOT MODIFY */
package edu.rosehulman.exam1sethruji;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}