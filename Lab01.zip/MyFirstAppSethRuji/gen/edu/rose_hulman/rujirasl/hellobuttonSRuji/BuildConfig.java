/** Automatically generated file. DO NOT MODIFY */
package edu.rose_hulman.rujirasl.hellobuttonSRuji;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}